-- phpMyAdmin SQL Dump
-- version 4.7.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 11, 2017 at 04:20 PM
-- Server version: 5.6.35
-- PHP Version: 7.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `clientlist`
--

-- --------------------------------------------------------

--
-- Table structure for table `table_clientlist`
--

CREATE TABLE `table_clientlist` (
  `id` int(11) NOT NULL,
  `name` char(100) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `table_clientlist`
--

INSERT INTO `table_clientlist` (`id`, `name`, `password`) VALUES
(1, 'mash', 'mash2'),
(2, 'Benson Toms', '4422'),
(3, 'Lucy Gatrfield', 'adsfafd'),
(4, 'Bob Brown', 'idk'),
(5, 'christina', 'perry'),
(6, 'Judy winch', '123'),
(7, 'Steve Lee', '344'),
(8, 'John riley', '1234'),
(9, 'Catherine Bates', '4432'),
(10, 'John riley', '1234'),
(11, 'Catherine Bates', '4432'),
(12, 'Rufus brown', 'what'),
(13, 'Zebedee josiah', '5678'),
(14, 'caroline', 'Hvac'),
(15, 'Jason Mraz', '9874'),
(16, 'Zebedee josiah', '5678'),
(17, 'Simon Higgins', '44421'),
(18, 'Michael josiah', '0000'),
(19, 'George Brown', '088'),
(20, 'Alphone Capone', '232'),
(21, 'Margaret Hikes', '2222'),
(22, 'Stanley Hope', '22333'),
(23, 'Stephen Luke', '232'),
(24, 'Stan', '0298092'),
(25, 'Hillary Bates', '9822');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `active` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password`, `active`) VALUES
(1, 'mash', 'mash@mash.com', 'mash', 0),
(2, 'jasper', 'jasper@jasper.com', 'jasper', 0),
(3, 'afsafdsa', 'mash@mash.com', 'mash', 0),
(5, 'david.kago@mail.com', 'david.kago@mail.com', 'mash', 0),
(7, 'mash1', 'mash@mash1.com', 'mash', 0),
(8, 'david', 'david@david.com', 'david', 0),
(9, 'james', 'james@james.com', 'james', 0),
(11, 'john', 'johnc@gmail.com', 'johnc', 0),
(12, 'kangura', 'kangura@gmail.com', 'kangura', 0),
(13, 'liz', 'liz@gmail.com', 'liz', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `table_clientlist`
--
ALTER TABLE `table_clientlist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `table_clientlist`
--
ALTER TABLE `table_clientlist`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;